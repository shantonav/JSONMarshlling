package org.custom.jackson.json;

public class GenericType {
    public String getPropertyName(){ return null; }

}
